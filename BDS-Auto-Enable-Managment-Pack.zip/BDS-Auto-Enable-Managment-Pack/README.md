# BDS-Auto-Enable-Managment-Pack
 Paczka do większej możliwości komunikacij pomiedzy BDS-Auto-Enable a serverem

**Szybkie info**:

* Paczke wystarczy tylko dodac do katalogu `TWÓJ ŚWIAT \behavior_backs` a program sam ją załaduje

