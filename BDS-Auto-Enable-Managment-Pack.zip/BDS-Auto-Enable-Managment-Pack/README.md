# BDS-Auto-Enable-Managment-Pack
 Paczka do większej możliwości komunikacij pomiedzy BDS-Auto-Enable a serverem

**Szybkie info**:

* Paczka sama się pobierze do twojego świata i załaduje , potrzebujesz jedynie włączonych experymentów w tym świecie!
